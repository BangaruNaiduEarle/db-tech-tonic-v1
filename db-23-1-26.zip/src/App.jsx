import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import ProductCatalog from './components/ProductCatalog';
import UnlockingSoftware from './components/UnlockingSoftware';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';
import PromoGrid from './components/PromoGrid';
import Banners from './components/Banners';
import PromoHighlights from './components/PromoHighlights';
import TrustFeatures from './components/TrustFeatures';
import CategoryTiles from './components/CategoryTiles';
import FeaturedCarousel from './components/FeaturedCarousel';
import PromoBanner from './components/PromoBanner';
import WhyChooseUs from './components/WhyChooseUs';

function App() {
  return (
    <div className="App">
      <Header />

      <main>
        {/* <Hero /> */}
        <div className="pt-16">

          <Banners />
        </div>
        <TrustFeatures />
        <CategoryTiles />
        <FeaturedCarousel />
        <PromoBanner />
        <WhyChooseUs />
        <PromoHighlights />

        <PromoGrid />
        <Services />
        <UnlockingSoftware />
        <ProductCatalog />
        
        <Testimonials />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
