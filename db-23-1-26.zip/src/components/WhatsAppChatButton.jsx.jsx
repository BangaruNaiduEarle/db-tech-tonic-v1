// components/WhatsAppChatButton.jsx
import { MessageCircle } from 'lucide-react';

export default function WhatsAppChatButton() {
  return (
    <a
      href="https://wa.me/919876543210" // Replace with your WhatsApp number
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg transition-all flex items-center justify-center"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="w-6 h-6" />
    </a>
  );
}
