import { useRef } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

const featuredProducts = [
  {
    id: 1,
    title: 'UnlockTool Pro Dongle',
    rating: 5,
    description: 'Lifetime license. Unlock 2000+ models incl. Xiaomi, Samsung, Huawei. Fast FRP removal & carrier unlock.',
    image: 'https://static.dhrufusion.com/8ba55f6b-3543-4e75-a3f9-3eb84c6a6176/2025/08/28/GD4gusbk_SamsungTool12Months.png',
  },
  {
    id: 2,
    title: 'Octoplus Box v4.0',
    rating: 4,
    description: 'Network unlock, FRP reset & IMEI repair for Samsung, LG, Huawei. Ships worldwide.',
    image: 'https://static.dhrufusion.com/8ba55f6b-3543-4e75-a3f9-3eb84c6a6176/2025/06/04/xl7WTg6j_HXRU_AUTH_TOOL.png',
  },
  {
    id: 3,
    title: 'iPhone 13 Pro Max OLED Screen',
    rating: 5,
    description: 'Genuine display assembly with frame. Crystal clear visuals. Best for pro repair centers.',
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    id: 4,
    title: 'Miracle Thunder Edition',
    rating: 4,
    description: 'Powerful all-in-one flashing & unlocking box. Supports Vivo, Lava, Itel, more.',
    image: 'https://static.dhrufusion.com/8ba55f6b-3543-4e75-a3f9-3eb84c6a6176/2025/06/04/bAQ40rzl_Android_Multi_Tool_Credits.png',
  },
  {
    id: 5,
    title: 'Samsung S20 Battery – 4000mAh',
    rating: 5,
    description: 'Reliable long-life battery. Lab-tested. Suits Galaxy S20 perfectly. 6-month warranty.',
    image: 'https://images.pexels.com/photos/4195325/pexels-photo-4195325.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];

export default function FeaturedCarousel() {
  const scrollRef = useRef(null);

  const scroll = (offset) => {
    scrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
  };

  return (
    <section className="py-16 bg-neutral-50" id="featured">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl md:text-4xl font-bold text-neutral-900">Featured Products</h2>
          <div className="hidden md:flex space-x-3">
            <button onClick={() => scroll(-300)} className="p-2 bg-white rounded-full shadow hover:bg-primary/10">
              <ChevronLeft />
            </button>
            <button onClick={() => scroll(300)} className="p-2 bg-white rounded-full shadow hover:bg-primary/10">
              <ChevronRight />
            </button>
          </div>
        </div>

        <div className="relative">
          <div
            ref={scrollRef}
            className="flex overflow-x-auto gap-6 snap-x scroll-smooth scrollbar-hide"
          >
            {featuredProducts.map((product) => (
              <div
                key={product.id}
                className="min-w-[260px] max-w-[260px] bg-white rounded-xl shadow hover:shadow-md flex-shrink-0 snap-start"
              >
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-40 object-cover rounded-t-xl"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-neutral-800 mb-1 text-sm">{product.title}</h3>
                  <div className="flex items-center space-x-1 text-yellow-400 mb-2">
                    {Array.from({ length: product.rating }).map((_, idx) => (
                      <Star key={idx} size={16} fill="currentColor" />
                    ))}
                  </div>
                  <p className="text-xs text-neutral-600 mb-3">{product.description}</p>
                  <div className="flex flex-col space-y-2">
                    <button className="w-full bg-primary text-white text-sm py-2 rounded hover:bg-primary-dark transition">
                      Add to Cart
                    </button>
                    <a
                      href="https://wa.me/911234567890"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full text-center text-primary border border-primary text-sm py-2 rounded hover:bg-primary/10 transition"
                    >
                      Enquire on WhatsApp
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Arrows for mobile */}
          <div className="flex justify-center space-x-4 mt-6 md:hidden">
            <button onClick={() => scroll(-260)} className="p-2 bg-white rounded-full shadow hover:bg-primary/10">
              <ChevronLeft />
            </button>
            <button onClick={() => scroll(260)} className="p-2 bg-white rounded-full shadow hover:bg-primary/10">
              <ChevronRight />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
