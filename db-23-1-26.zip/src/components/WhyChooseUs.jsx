import { ShieldCheck, CreditCard, Clock, Star, Truck, BadgeCheck } from 'lucide-react';

const valueProps = [
  {
    icon: <ShieldCheck className="w-6 h-6 text-primary" />,
    title: "Genuine Parts Only",
    desc: "Original OEM screens, batteries, and modules for trusted repairs.",
  },
  {
    icon: <Clock className="w-6 h-6 text-primary" />,
    title: "Instant Delivery",
    desc: "Licenses & credits activated immediately upon purchase.",
  },
  {
    icon: <Star className="w-6 h-6 text-primary" />,
    title: "30-Day Warranty",
    desc: "Easy returns and replacement on all eligible items.",
  },
  {
    icon: <Truck className="w-6 h-6 text-primary" />,
    title: "Global Fast Shipping",
    desc: "Delivery available worldwide via trusted logistics partners.",
  },
  {
    icon: <CreditCard className="w-6 h-6 text-primary" />,
    title: "Secure Payments",
    desc: "100% secure checkout – PayPal, Crypto (USDT), Cards accepted.",
  },
  {
    icon: <BadgeCheck className="w-6 h-6 text-primary" />,
    title: "Verified Seller",
    desc: "Official distributor for UnlockTool, Octoplus, Miracle & more.",
  },
];

export default function WhyChooseUs() {
  return (
    <section className="bg-white py-16" id="why-us">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-neutral-900 mb-12">
          Why Choose DB TECH TONIC?
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {valueProps.map((item, i) => (
            <div key={i} className="flex items-start space-x-4">
              <div className="flex-shrink-0">
                {item.icon}
              </div>
              <div>
                <h4 className="text-lg font-semibold text-neutral-800 mb-1">
                  {item.title}
                </h4>
                <p className="text-sm text-neutral-600">
                  {item.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
