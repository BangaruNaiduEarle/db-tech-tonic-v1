import { ShieldCheck, Truck, Clock, Globe, Lock, BadgeCheck } from 'lucide-react';

const features = [
  {
    icon: <ShieldCheck className="w-6 h-6 text-primary" />,
    title: 'Verified Seller',
    desc: 'Official Distributor of Octoplus, Miracle Box & UMT.',
  },
  {
    icon: <Truck className="w-6 h-6 text-primary" />,
    title: 'Fast Delivery',
    desc: 'Same-day dispatch. Global GSM tool shipping via DHL, FedEx.',
  },
  {
    icon: <Clock className="w-6 h-6 text-primary" />,
    title: '24/7 Support',
    desc: 'Round-the-clock technical assistance for all tools.',
  },
  {
    icon: <Lock className="w-6 h-6 text-primary" />,
    title: 'Secure Payment',
    desc: '100% secure checkout via PayPal, Credit Card, USDT.',
  },
  {
    icon: <Globe className="w-6 h-6 text-primary" />,
    title: 'Worldwide Shipping',
    desc: 'Delivering to 180+ countries. Bulk orders supported.',
  },
  {
    icon: <BadgeCheck className="w-6 h-6 text-primary" />,
    title: 'Trusted Supplier',
    desc: 'Supplying GSM parts & tools since 2020 with 10k+ happy customers.',
  },
];

export default function TrustFeatures() {
  return (
    <section className="bg-white py-16" id="trust-signals">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold text-neutral-900">
            Why Technicians Trust DB Tech Tonic
          </h2>
          <p className="mt-2 text-neutral-600 max-w-2xl mx-auto text-base">
            Fast, Secure GSM Tool Delivery – Verified Worldwide. Trusted by thousands of mobile repair experts.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((item, idx) => (
            <div key={idx} className="bg-neutral-50 p-6 rounded-xl shadow-sm hover:shadow-md transition">
              <div className="flex items-center space-x-4 mb-3">
                {item.icon}
                <h4 className="text-lg font-semibold text-neutral-800">{item.title}</h4>
              </div>
              <p className="text-sm text-neutral-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
