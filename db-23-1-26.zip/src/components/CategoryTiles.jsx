const categories = [
    {
      title: 'iPhone & Android Spare Parts',
      keyword: 'Screens, Batteries, Cameras & More for iPhone, Samsung, Xiaomi…',
      image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=600',
      link: '/category/spare-parts',
    },
    {
      title: 'Unlocking Tools & Licenses',
      keyword: 'Unlock FRP, Pattern & Carrier locks on Android/iOS',
      image: 'https://static.dhrufusion.com/8ba55f6b-3543-4e75-a3f9-3eb84c6a6176/2025/08/28/GD4gusbk_SamsungTool12Months.png',
      link: '/category/unlocking-tools',
    },
    {
      title: 'Dongles & Flash Boxes',
      keyword: 'Octoplus, Miracle, UMT, Z3X & more for JTAG/USB Repair',
      image: 'https://static.dhrufusion.com/8ba55f6b-3543-4e75-a3f9-3eb84c6a6176/2025/06/04/xl7WTg6j_HXRU_AUTH_TOOL.png',
      link: '/category/flash-dongles',
    },
    {
      title: 'Accessories & Cables',
      keyword: 'Data Cables, Adapters, Jumpers & Repair Accessories',
      image: 'https://images.pexels.com/photos/699122/pexels-photo-699122.jpeg?auto=compress&cs=tinysrgb&w=600',
      link: '/category/accessories',
    },
    {
      title: 'Server Credits',
      keyword: 'Instant FRP, IMEI, iCloud Credits – Auto-Activated',
      image: 'https://static.dhrufusion.com/8ba55f6b-3543-4e75-a3f9-3eb84c6a6176/2025/06/04/bAQ40rzl_Android_Multi_Tool_Credits.png',
      link: '/category/server-credits',
    },
    {
      title: 'Bundles & Promotions',
      keyword: 'Combo Bundles: Tools + Parts Packages',
      image: 'https://images.pexels.com/photos/1092644/pexels-photo-1092644.jpeg?auto=compress&cs=tinysrgb&w=600',
      link: '/category/bundles',
    },
  ];
  
  export default function CategoryTiles() {
    return (
      <section className="py-16 bg-white" id="categories">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-neutral-900 mb-10">
            Shop by Category
          </h2>
  
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((cat, idx) => (
              <a
                key={idx}
                href={cat.link}
                className="group block rounded-xl overflow-hidden shadow-sm hover:shadow-md transition"
              >
                <div className="h-48 sm:h-56 lg:h-60 overflow-hidden">
                  <img
                    src={cat.image}
                    alt={cat.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4 bg-neutral-50">
                  <h3 className="text-lg font-semibold text-neutral-800 mb-1">
                    {cat.title}
                  </h3>
                  <p className="text-sm text-neutral-600">{cat.keyword}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>
    );
  }
  