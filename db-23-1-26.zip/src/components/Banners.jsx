import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const slides = [
  {
    title: "Unlock & Repair Phones with Top-Quality GSM Tools",
    subtitle: "Professional-Grade FRP & IMEI Solutions",
    image: "https://images.pexels.com/photos/6078123/pexels-photo-6078123.jpeg?auto=compress&cs=tinysrgb&w=1600",
    cta: { label: "Shop Now", href: "#shop" },
  },
  {
    title: "Summer Sale – 10% OFF All Unlocking Tools",
    subtitle: "Limited Time Offer – Lifetime Licenses Available",
    image: "https://images.pexels.com/photos/6078120/pexels-photo-6078120.jpeg?auto=compress&cs=tinysrgb&w=1600",
    cta: { label: "Buy Now", href: "#unlocking" },
  },
  {
    title: "Shop Genuine Phone Repair Parts – iPhone, Samsung, Xiaomi",
    subtitle: "OEM Displays, Batteries & Back Glass in Stock",
    image: "https://images.pexels.com/photos/5076524/pexels-photo-5076524.jpeg?auto=compress&cs=tinysrgb&w=1600",
    cta: { label: "Enquire on WhatsApp", href: "https://wa.me/911234567890" },
  },
];

export default function HeroBanner() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % slides.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="home" className="relative h-[80vh] md:h-[90vh] w-full overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={index}
          initial={{ opacity: 0.5 }}
          animate={{ opacity: 0.8 }}
          exit={{ opacity: 0.8 }}
          transition={{ duration: 0.6 }}
          className="absolute inset-0"
        >
          <img
            src={slides[index].image}
            alt={slides[index].title}
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-black/20" />
          <div className="absolute inset-0 flex flex-col items-center justify-center px-4 text-center text-white">
            <motion.h1
              className="text-3xl sm:text-4xl md:text-5xl font-bold max-w-3xl mb-4 leading-tight"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              {slides[index].title}
            </motion.h1>
            <motion.p
              className="text-lg md:text-xl text-neutral-200 max-w-xl mb-6"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              {slides[index].subtitle}
            </motion.p>
            <motion.a
              href={slides[index].cta.href}
              className="inline-block bg-primary hover:bg-primary-dark text-white font-semibold px-6 py-3 rounded-lg transition"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.7 }}
            >
              {slides[index].cta.label}
            </motion.a>
          </div>
        </motion.div>
      </AnimatePresence>
    </section>
  );
}
