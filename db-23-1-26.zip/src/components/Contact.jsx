import { useState } from 'react';
import { motion } from 'framer-motion';
import { Instagram, Facebook, Twitter, Clock, Phone, Mail, MapPinHouse  } from 'lucide-react';



export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    serviceType: 'repair',
    message: '',
  });

  const [showToast, setShowToast] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submission ready:', formData);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
    setFormData({ name: '', phone: '', serviceType: 'repair', message: '' });
  };

  return (
    <section id="contact" className="py-20 bg-neutral-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-4">
            Contact Us
          </h2>
          <p className="text-lg text-neutral-600 max-w-2xl mx-auto">
            Visit our store or book a repair online
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h3 className="text-xl font-bold text-neutral-900 mb-4">
                Visit Our Store
              </h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="text-2xl"><MapPinHouse /></div>
                  <div>
                    <p className="font-semibold text-neutral-900">Address</p>
                    <p className="text-neutral-600">
                      123 Tech Street, Electronics Market
                      <br />
                      Mumbai, Maharashtra 400001
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="text-2xl"><Clock /></div>
                  <div>
                    <p className="font-semibold text-neutral-900">Business Hours</p>
                    <p className="text-neutral-600">
                      Monday - Saturday: 10:00 AM - 8:00 PM
                      <br />
                      Sunday: 11:00 AM - 6:00 PM
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="text-2xl"><Phone /></div>
                  <div>
                    <p className="font-semibold text-neutral-900">Phone</p>
                    <a
                      href="tel:+911234567890"
                      className="text-primary hover:text-primary-dark transition-colors font-medium"
                    >
                      +91 123 456 7890
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="text-2xl"><Mail /></div>
                  <div>
                    <p className="font-semibold text-neutral-900">Email</p>
                    <a
                      href="mailto:info@dbtechtonic.com"
                      className="text-primary hover:text-primary-dark transition-colors font-medium"
                    >
                      info@dbtechtonic.com
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 shadow-sm">
              <h3 className="text-xl font-bold text-neutral-900 mb-4">Connect With Us</h3>
              <div className="flex flex-wrap space-x-4">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-gradient-to-br from-purple-500 to-pink-500 text-white rounded-lg hover:shadow-lg transition-all"
                >
                  <span className="text-xl"><Instagram /></span>
                  <span className="font-medium">Instagram</span>
                </a>
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 text-white rounded-lg hover:shadow-lg transition-all"
                >
                  <span className="text-xl"><Facebook /></span>
                  <span className="font-medium">Facebook</span>
                </a>
                <a
                  href="https://twitter.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center space-x-2 px-4 py-3 bg-sky-500 text-white rounded-lg hover:shadow-lg transition-all"
                >
                  <span className="text-xl"><Twitter /></span>
                  <span className="font-medium">Twitter</span>
                </a>
              </div>
            </div>

            <div className="bg-white rounded-xl overflow-hidden shadow-sm h-64">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3772.1234567890123!2d72.8776559!3d19.0759837!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTnCsDA0JzMzLjUiTiA3MsKwNTInMzkuNiJF!5e0!3m2!1sen!2sin!4v1234567890123"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="DB Tech Tonic Location"
              ></iframe>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-white rounded-xl p-6 md:p-8 shadow-sm"
          >
            <h3 className="text-xl font-bold text-neutral-900 mb-6">Book a Repair</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-neutral-700 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="Enter your name"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-neutral-700 mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  pattern="[0-9]{10}"
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  placeholder="10-digit mobile number"
                />
              </div>

              <div>
                <label
                  htmlFor="serviceType"
                  className="block text-sm font-medium text-neutral-700 mb-2"
                >
                  Service Type
                </label>
                <select
                  id="serviceType"
                  name="serviceType"
                  value={formData.serviceType}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                >
                  <option value="repair">Screen/Battery Repair</option>
                  <option value="diagnostic">Diagnostic & Software</option>
                  <option value="unlocking">Unlocking Service</option>
                  <option value="parts">Spare Parts Inquiry</option>
                  <option value="wholesale">Wholesale/Bulk Order</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="message"
                  className="block text-sm font-medium text-neutral-700 mb-2"
                >
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows="4"
                  required
                  className="w-full px-4 py-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent resize-none"
                  placeholder="Describe your device issue or inquiry"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full px-6 py-4 bg-primary hover:bg-primary-dark text-white font-semibold rounded-lg transition-all transform hover:scale-105 shadow-lg hover:shadow-xl"
              >
                Book Repair
              </button>
            </form>
          </motion.div>
        </div>
      </div>

      {showToast && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          className="fixed bottom-8 right-8 bg-green-500 text-white px-6 py-4 rounded-lg shadow-xl z-50"
        >
          <p className="font-medium">Form submitted successfully! We'll contact you soon.</p>
        </motion.div>
      )}
    </section>
  );
}
